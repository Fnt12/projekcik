import { Component, OnInit } from '@angular/core';
import { MessengerService } from 'src/app/service/messenger.service'
import { Items } from 'src/app/models/items';

@Component({
  selector: 'app-koszyk',
  templateUrl: './koszyk.component.html',
  styleUrls: ['./koszyk.component.css']
})
export class KoszykComponent implements OnInit {

  koszykItems = [
  //   { id: 1, itemsID: 1, itemName: 'Test 1', qty: 3, price: 100},
  //   { id: 2, itemsID: 3, itemName: 'Test 2', qty: 5, price: 200},
  //   { id: 3, itemsID: 2, itemName: 'Test 3', qty: 8, price: 50},
  //   { id: 4, itemsID: 4, itemName: 'Test 4', qty: 2, price: 150},
  ];

  koszykRazem = 0

  constructor(private msg: MessengerService) {

   }

  ngOnInit() {

    this.msg.getMsg().subscribe((produkt: Items) =>{
      this.addProductToCart(produkt)
  })
  }
  addProductToCart(produkt: Items){

    this.koszykItems.push({
      itemName: produkt.name,
      qty: 1,
      price: produkt.price

    })
  this.koszykRazem = 0
  this.koszykItems.forEach(i => {
    this.koszykRazem += (i.qty * i.price)
  })
  }
}
