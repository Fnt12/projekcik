import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filtry',
  templateUrl: './filtry.component.html',
  styleUrls: ['./filtry.component.css']
})
export class FiltryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
