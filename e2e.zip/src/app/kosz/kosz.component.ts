import { Component, OnInit } from '@angular/core';

import { ItemsService } from 'src/app/service/items.service'
import { Items } from 'src/app/models/items';

@Component({
  selector: 'app-kosz',
  templateUrl: './kosz.component.html',
  styleUrls: ['./kosz.component.css']
})
export class KoszComponent implements OnInit {

  itemsList: Items[] = []


  constructor(private itemsService: ItemsService) { }

  ngOnInit(){
    this.itemsList = this.itemsService.getItems()
  }

}
