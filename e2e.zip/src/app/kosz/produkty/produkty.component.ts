import { Component, OnInit, Input } from '@angular/core';
import { Items } from 'src/app/models/items'
import { MessengerService } from 'src/app/service/messenger.service'

@Component({
  selector: 'app-produkty',
  templateUrl: './produkty.component.html',
  styleUrls: ['./produkty.component.css']
})
export class ProduktyComponent implements OnInit {

  @Input() produktItem: Items

  constructor(private msg: MessengerService) { }

  ngOnInit(){
  }

  handleAddToCart(){
    this.msg.sendMsg(this.produktItem)
  }

}
