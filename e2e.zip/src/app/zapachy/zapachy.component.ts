import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zapachy',
  templateUrl: './zapachy.component.html',
  styleUrls: ['./zapachy.component.css']
})
export class ZapachyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
