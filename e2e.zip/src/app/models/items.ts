import { ThrowStmt } from '@angular/compiler';

export class Items {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;

  constructor(id, name, description = '', price, category = '', imageUrl = 'https://cdn.discordapp.com/attachments/704764867671752774/715517970641584128/Kosmoteo_200x200_Logo.png'){
    this.id = id
    this.name = name
    this.description = description
    this.price = price
    this.category = category
    this.imageUrl = imageUrl



  }
}
