import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-twarz',
  templateUrl: './twarz.component.html',
  styleUrls: ['./twarz.component.css']
})
export class TwarzComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
