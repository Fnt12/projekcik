import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ochronne',
  templateUrl: './ochronne.component.html',
  styleUrls: ['./ochronne.component.css']
})
export class OchronneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
