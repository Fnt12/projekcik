import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zdrowie',
  templateUrl: './zdrowie.component.html',
  styleUrls: ['./zdrowie.component.css']
})
export class ZdrowieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
