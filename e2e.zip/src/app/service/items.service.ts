import { Injectable } from '@angular/core';

import { Items } from '../models/items'

@Injectable({
  providedIn: 'root'
})
export class ItemsService {
//Produkty z api
  items: Items[] = [
    new Items(1, '1 produkt', 'to jest 1 produkt i jest super :)', 100, 'Perfumy','https://cdn.discordapp.com/attachments/519199421557112865/717131196802400266/IMG_20200601_234259.jpg'),
    new Items(2, '2 produkt', 'to jest 2 produkt i jest super :)', 200),
    new Items(3, '3 produkt', 'to jest 3 produkt i jest super :)', 250,),
    new Items(4, '4 produkt', 'to jest 4 produkt i jest super :)', 50,),
    new Items(5, '5 produkt', 'to jest 5 produkt i jest super :)', 300,),
  ]

  constructor() { }

  getItems(): Items[] {
    return this.items
  }
}
