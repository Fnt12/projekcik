import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HigienaComponent } from './higiena.component';

describe('HigienaComponent', () => {
  let component: HigienaComponent;
  let fixture: ComponentFixture<HigienaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HigienaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HigienaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
