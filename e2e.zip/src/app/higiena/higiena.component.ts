import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-higiena',
  templateUrl: './higiena.component.html',
  styleUrls: ['./higiena.component.css']
})
export class HigienaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
