import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrzedmiotComponent } from './przedmiot.component';

describe('PrzedmiotComponent', () => {
  let component: PrzedmiotComponent;
  let fixture: ComponentFixture<PrzedmiotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrzedmiotComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrzedmiotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
