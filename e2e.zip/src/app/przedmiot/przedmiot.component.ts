import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-przedmiot',
  templateUrl: './przedmiot.component.html',
  styleUrls: ['./przedmiot.component.css']
})
export class PrzedmiotComponent implements OnInit {

  @Input() koszykItems: any

  constructor() { }

  ngOnInit(){
  }

}
