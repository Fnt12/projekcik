import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promocje',
  templateUrl: './promocje.component.html',
  styleUrls: ['./promocje.component.css']
})
export class PromocjeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
