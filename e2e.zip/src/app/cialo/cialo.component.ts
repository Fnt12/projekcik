import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cialo',
  templateUrl: './cialo.component.html',
  styleUrls: ['./cialo.component.css']
})
export class CialoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
