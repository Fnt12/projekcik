import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CialoComponent } from './cialo.component';

describe('CialoComponent', () => {
  let component: CialoComponent;
  let fixture: ComponentFixture<CialoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CialoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CialoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
