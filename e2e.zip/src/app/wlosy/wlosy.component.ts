import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wlosy',
  templateUrl: './wlosy.component.html',
  styleUrls: ['./wlosy.component.css']
})
export class WlosyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
