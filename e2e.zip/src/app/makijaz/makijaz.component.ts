import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-makijaz',
  templateUrl: './makijaz.component.html',
  styleUrls: ['./makijaz.component.css']
})
export class MakijazComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
