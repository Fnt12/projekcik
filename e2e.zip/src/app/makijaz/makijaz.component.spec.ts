import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MakijazComponent } from './makijaz.component';

describe('MakijazComponent', () => {
  let component: MakijazComponent;
  let fixture: ComponentFixture<MakijazComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MakijazComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MakijazComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
